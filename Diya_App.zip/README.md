# Diya (দিয়া) — AI Assistant

## GitHub এ বিল্ড
1. zip এক্সট্র্যাক্ট করো। (লুকানো `.github` ফোল্ডারসহ) সব ফাইল GitHub রিপোজিটরির রুটে আপলোড করো।
2. Actions ট্যাব → "Build Diya APK" → Run workflow (বা push করলেই চলবে)।
3. শেষ হলে Artifacts থেকে Diya-APK ডাউনলোড করো।

## প্রথমবার
- Settings এ Gemini/Groq API key দাও → Save & Test
- Accessibility সেটিংস থেকে Diya চালু করো, "Display over other apps" দাও
