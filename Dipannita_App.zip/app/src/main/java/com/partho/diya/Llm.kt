package com.partho.diya

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Gemini আগে, লিমিট শেষ/ব্যর্থ হলে পরের key, সব Gemini key ব্যর্থ হলে Groq */
object Llm {
    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()
    private val JSON = "application/json".toMediaType()

    fun keys(s: String) = s.lines().map { it.trim() }.filter { it.isNotEmpty() }

    private fun post(url: String, body: JSONObject, headers: Map<String, String>): String {
        val rb = Request.Builder().url(url).post(body.toString().toRequestBody(JSON))
        headers.forEach { (k, v) -> rb.header(k, v) }
        http.newCall(rb.build()).execute().use { r ->
            val s = r.body?.string() ?: ""
            if (!r.isSuccessful) throw Exception("HTTP ${r.code}: ${s.take(200)}")
            return s
        }
    }

    private fun gemini(key: String, sys: String, msgs: List<Msg>, json: Boolean): String {
        val contents = JSONArray()
        for (m in msgs) {
            val parts = JSONArray()
            parts.put(JSONObject().put("text", m.text.ifBlank { " " }))
            for ((mt, d) in m.images) {
                parts.put(JSONObject().put("inlineData", JSONObject().put("mimeType", mt).put("data", d)))
            }
            contents.put(JSONObject().put("role", m.role).put("parts", parts))
        }
        val body = JSONObject().put("contents", contents)
        if (sys.isNotBlank()) {
            body.put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
        }
        if (json) body.put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        val res = post(
            "https://generativelanguage.googleapis.com/v1beta/models/${Store.geminiModel}:generateContent",
            body, mapOf("x-goog-api-key" to key)
        )
        val parts = JSONObject(res).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        return sb.toString()
    }

    private fun groq(key: String, sys: String, msgs: List<Msg>): String {
        val arr = JSONArray()
        arr.put(JSONObject().put("role", "system").put("content", sys))
        for (m in msgs) {
            val extra = if (m.images.isNotEmpty()) "\n[ছবি/ভিডিও সংযুক্ত আছে — এই মডেল তা দেখতে পারে না]" else ""
            arr.put(JSONObject().put("role", if (m.role == "model") "assistant" else "user").put("content", m.text + extra))
        }
        val body = JSONObject().put("model", Store.groqModel).put("messages", arr)
        val res = post("https://api.groq.com/openai/v1/chat/completions", body, mapOf("Authorization" to "Bearer $key"))
        return JSONObject(res).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
    }

    suspend fun ask(sys: String, msgs: List<Msg>): String = withContext(Dispatchers.IO) {
        var err = "কোনো API key সেট করা নেই (Settings এ যাও)"
        val g = keys(Store.geminiKeys)
        if (g.isNotEmpty()) {
            val start = Store.gIdx
            for (i in g.indices) {
                val idx = (start + i) % g.size
                try {
                    val r = gemini(g[idx], sys, msgs, true)
                    Store.gIdx = idx
                    return@withContext r
                } catch (e: Exception) { err = "Gemini: ${e.message}" }
            }
        }
        val q = keys(Store.groqKeys)
        if (q.isNotEmpty()) {
            val start = Store.qIdx
            for (i in q.indices) {
                val idx = (start + i) % q.size
                try {
                    val r = groq(q[idx], sys, msgs)
                    Store.qIdx = idx
                    return@withContext r
                } catch (e: Exception) { err = "Groq: ${e.message}" }
            }
        }
        throw Exception(err)
    }

    /** Save & Test বাটনের জন্য: প্রতিটি key আলাদা করে টেস্ট করে */
    suspend fun test(provider: String): String = withContext(Dispatchers.IO) {
        val ks = keys(if (provider == "gemini") Store.geminiKeys else Store.groqKeys)
        if (ks.isEmpty()) return@withContext "❌ কোনো key নেই"
        val out = StringBuilder()
        ks.forEachIndexed { i, k ->
            try {
                val m = listOf(Msg("user", "Say OK"))
                if (provider == "gemini") gemini(k, "", m, false) else groq(k, "Reply briefly", m)
                out.append("✅ key ${i + 1} কাজ করছে\n")
            } catch (e: Exception) {
                out.append("❌ key ${i + 1}: ${e.message?.take(90)}\n")
            }
        }
        out.toString().trim()
    }
}
