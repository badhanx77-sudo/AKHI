package com.partho.diya

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.telecom.TelecomManager
import android.telephony.SmsManager
import android.webkit.MimeTypeMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

object Actions {
    lateinit var app: Context
    @Volatile var lastShot: String? = null
    @Volatile var lastImage: String? = null
    private const val NO_ACC = "Accessibility সার্ভিস চালু নেই (Settings → Accessibility চালু করো)"

    private fun acc() = DiyaAccess.inst

    private fun launch(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        (DiyaAccess.inst ?: app).startActivity(i)
    }

    private fun resolve(q: String): String? {
        if (q.count { it.isDigit() } >= 6) return q.filter { it.isDigit() || it == '+' }
        val c = app.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        )
        c?.use { while (it.moveToNext()) { if (it.getString(0).contains(q, true)) return it.getString(1) } }
        return null
    }

    private fun waNum(n: String): String {
        val d = n.filter { it.isDigit() }
        return if (d.startsWith("0")) "88$d" else d
    }

    private fun openApp(name: String): String {
        val pm = app.packageManager
        val alias = mapOf(
            "whatsapp" to "com.whatsapp", "tiktok" to "com.zhiliaoapp.musically",
            "instagram" to "com.instagram.android", "facebook" to "com.facebook.katana",
            "messenger" to "com.facebook.orca", "youtube" to "com.google.android.youtube",
            "chrome" to "com.android.chrome", "telegram" to "org.telegram.messenger"
        )
        val n = name.lowercase().trim()
        var pkg = alias.entries.firstOrNull { n.contains(it.key) }?.value
            ?.takeIf { pm.getLaunchIntentForPackage(it) != null }
        if (pkg == null) {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pkg = pm.queryIntentActivities(i, 0)
                .firstOrNull { it.loadLabel(pm).toString().lowercase().contains(n) }?.activityInfo?.packageName
        }
        val li = pkg?.let { pm.getLaunchIntentForPackage(it) } ?: return "'$name' অ্যাপ পাওয়া যায়নি"
        launch(li)
        return "$name খোলা হয়েছে"
    }

    private fun mime(name: String): String =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "txt")) ?: "text/plain"

    private fun createFile(name: String, content: String): String {
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, mime(name))
                put(MediaStore.Downloads.RELATIVE_PATH, "Download/Dipannita")
            }
            val uri = app.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: return "ফাইল তৈরি ব্যর্থ"
            app.contentResolver.openOutputStream(uri)?.use { it.write(content.toByteArray()) }
            return "Download/Dipannita/$name তৈরি হয়েছে"
        }
        val f = File(app.getExternalFilesDir(null), name)
        f.writeText(content)
        return "${f.path} তৈরি হয়েছে"
    }

    private fun openFile(name: String): String {
        if (Build.VERSION.SDK_INT < 29) return "এই Android সংস্করণে সমর্থিত নয়"
        val c = app.contentResolver.query(
            MediaStore.Files.getContentUri("external"), arrayOf(MediaStore.Files.FileColumns._ID),
            "${MediaStore.Files.FileColumns.DISPLAY_NAME}=?", arrayOf(name), null
        )
        c?.use {
            if (it.moveToFirst()) {
                val uri = Uri.withAppendedPath(MediaStore.Files.getContentUri("external"), it.getLong(0).toString())
                launch(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime(name)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                return "$name খোলা হয়েছে"
            }
        }
        return "$name ফাইল পাইনি"
    }

    private fun saveToGallery(b: ByteArray) {
        if (Build.VERSION.SDK_INT < 29) return
        val cv = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "diya_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Dipannita")
        }
        val u = app.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: return
        app.contentResolver.openOutputStream(u)?.use { it.write(b) }
    }

    private suspend fun genImage(p: String): String = withContext(Dispatchers.IO) {
        val u = "https://image.pollinations.ai/prompt/" + URLEncoder.encode(p, "UTF-8").replace("+", "%20") +
            "?width=1024&height=1024&nologo=true"
        val c = OkHttpClient.Builder().readTimeout(120, TimeUnit.SECONDS).build()
        c.newCall(Request.Builder().url(u).build()).execute().use { r ->
            if (!r.isSuccessful) return@withContext "ছবি তৈরি ব্যর্থ (${r.code})"
            val b = r.body!!.bytes()
            val f = File(app.cacheDir, "gen_${System.currentTimeMillis()}.jpg")
            f.writeBytes(b)
            saveToGallery(b)
            lastImage = f.path
            "ছবি তৈরি হয়েছে ও গ্যালারিতে সেভ হয়েছে"
        }
    }

    private suspend fun unlock(): String {
        val pin = Store.pin
        if (pin.isBlank()) return "Settings এ আনলক PIN/পাসওয়ার্ড সেট করা নেই"
        val s = acc() ?: return NO_ACC
        val pm = app.getSystemService(Context.POWER_SERVICE) as PowerManager
        @Suppress("DEPRECATION")
        val wl = pm.newWakeLock(PowerManager.FULL_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "diya:wake")
        wl.acquire(6000)
        delay(800)
        val (w, h) = s.screenSize()
        s.swipe(w / 2, h * 0.85f, w / 2, h * 0.25f, 350)
        delay(900)
        if (pin.all { it.isDigit() }) {
            for (ch in pin) { s.clickText(ch.toString()); delay(180) }
        } else s.typeText(pin)
        return "আনলক চেষ্টা করা হয়েছে (best-effort)"
    }

    @Suppress("DEPRECATION", "MissingPermission")
    suspend fun run(a: JSONObject): String {
        return when (val t = a.optString("type")) {
            "open_app" -> { val r = openApp(a.optString("app")); delay(1800); r }
            "open_url" -> { launch(Intent(Intent.ACTION_VIEW, Uri.parse(a.optString("url")))); delay(1500); "লিংক খোলা হয়েছে" }
            "call" -> {
                val n = resolve(a.optString("to")) ?: return "নম্বর পাওয়া যায়নি"
                launch(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(n))))
                "কল করা হচ্ছে $n"
            }
            "answer_call" -> try {
                (app.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).acceptRingingCall(); "কল রিসিভ করা হয়েছে"
            } catch (e: Exception) { "কল রিসিভ ব্যর্থ: ${e.message}" }
            "end_call" -> try {
                (app.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).endCall(); "কল কাটা হয়েছে"
            } catch (e: Exception) { "কল কাটা ব্যর্থ: ${e.message}" }
            "sms" -> {
                val n = resolve(a.optString("to")) ?: return "নম্বর পাওয়া যায়নি"
                @Suppress("DEPRECATION")
                val sm = SmsManager.getDefault()
                sm.sendMultipartTextMessage(n, null, sm.divideMessage(a.optString("text")), null, null)
                "SMS পাঠানো হয়েছে"
            }
            "whatsapp" -> {
                val n = resolve(a.optString("to")) ?: return "নম্বর পাওয়া যায়নি"
                launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${waNum(n)}?text=" + Uri.encode(a.optString("text")))).setPackage("com.whatsapp"))
                delay(3200)
                val s = acc()
                if (s != null && (s.clickText("Send") || s.clickText("পাঠান"))) "WhatsApp এ পাঠানো হয়েছে"
                else "চ্যাট খোলা হয়েছে, Send বাটন পাইনি"
            }
            "click" -> acc()?.let { if (it.clickText(a.optString("text"))) "ক্লিক হয়েছে" else "'${a.optString("text")}' পাইনি" } ?: NO_ACC
            "type" -> acc()?.let { if (it.typeText(a.optString("text"))) "টাইপ হয়েছে" else "ইনপুট ফিল্ড পাইনি" } ?: NO_ACC
            "key" -> acc()?.let { it.global(a.optString("key")); "ok" } ?: NO_ACC
            "scroll" -> acc()?.let {
                val (w, h) = it.screenSize()
                if (a.optString("dir") == "up") it.swipe(w / 2, h * 0.3f, w / 2, h * 0.7f) else it.swipe(w / 2, h * 0.7f, w / 2, h * 0.3f)
                delay(500); "স্ক্রল হয়েছে"
            } ?: NO_ACC
            "tap" -> acc()?.let { it.tap(a.optDouble("x").toFloat(), a.optDouble("y").toFloat()); "ট্যাপ হয়েছে" } ?: NO_ACC
            "swipe" -> acc()?.let {
                it.swipe(a.optDouble("x1").toFloat(), a.optDouble("y1").toFloat(), a.optDouble("x2").toFloat(), a.optDouble("y2").toFloat()); "সোয়াইপ হয়েছে"
            } ?: NO_ACC
            "wait" -> { delay(a.optLong("ms", 1000).coerceIn(100, 8000)); "অপেক্ষা শেষ" }
            "read_screen" -> acc()?.dump() ?: NO_ACC
            "look" -> {
                val s = if (Build.VERSION.SDK_INT >= 30) acc()?.shot() else null
                lastShot = s
                if (s != null) "স্ক্রিনশট সংযুক্ত" else "স্ক্রিনশট নেওয়া যায়নি"
            }
            "clipboard" -> withContext(Dispatchers.Main) {
                (app.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("diya", a.optString("text")))
                "ক্লিপবোর্ডে কপি হয়েছে"
            }
            "create_file" -> createFile(a.optString("name", "note.txt"), a.optString("content"))
            "open_file" -> openFile(a.optString("name"))
            "remember" -> { Store.addMemory(a.optString("text")); "মনে রাখলাম" }
            "forget" -> { Store.forget(a.optString("text")); "ভুলে গেলাম" }
            "unlock" -> unlock()
            "gen_image" -> genImage(a.optString("prompt"))
            "alarm" -> {
                launch(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour"))
                    .putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute")).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                "অ্যালার্ম সেট হয়েছে"
            }
            "ha" -> {
                val base = Store.haUrl.trimEnd('/')
                if (base.isBlank()) return "Home Assistant সেট করা নেই"
                val body = JSONObject().put("entity_id", a.optString("entity_id"))
                val req = Request.Builder()
                    .url("$base/api/services/${a.optString("domain")}/${a.optString("service")}")
                    .header("Authorization", "Bearer ${Store.haToken}")
                    .post(body.toString().toRequestBody("application/json".toMediaType())).build()
                withContext(Dispatchers.IO) { OkHttpClient().newCall(req).execute().use { "Home Assistant: HTTP ${it.code}" } }
            }
            else -> "অজানা অ্যাকশন: $t"
        }
    }
}
