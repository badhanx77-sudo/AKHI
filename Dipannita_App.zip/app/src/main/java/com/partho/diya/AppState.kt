package com.partho.diya

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

object AppState {
    var screen by mutableStateOf(Screen.HOME)
    var listening by mutableStateOf(false)
    var speaking by mutableStateOf(false)
    var busy by mutableStateOf(false)
    var level by mutableStateOf(0f)
    var status by mutableStateOf("")
    var partial by mutableStateOf("")
    var lastReply by mutableStateOf("")
    var name by mutableStateOf("Badhan")
    var pendingAtt by mutableStateOf<Att?>(null)
    val msgs = mutableStateListOf<ChatMsg>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    fun loadHistory() {
        name = Store.userName
        if (msgs.isEmpty()) Store.history().takeLast(30).forEach { msgs.add(ChatMsg(it.first == "user", it.second)) }
    }

    private fun clean(s: String) = s.replace(Regex("[*#_`>]"), "").replace(Regex("\\s+"), " ").trim()

    fun send(text: String, att: Att?, voice: Boolean) {
        if (busy || (text.isBlank() && att == null)) return
        msgs.add(ChatMsg(true, text.ifBlank { "📎 ${att?.name}" }, null, att?.name))
        busy = true
        status = "ভাবছি…"
        scope.launch {
            val r = try {
                withContext(Dispatchers.Default) { Agent.handle(text, att) { status = it } }
            } catch (e: Exception) {
                Pair<String, String?>("⚠️ ${e.message}", null)
            }
            msgs.add(ChatMsg(false, r.first, r.second))
            lastReply = r.first
            busy = false
            status = ""
            if (voice || Store.speakAll == "1") DiyaVoice.speak(clean(r.first))
        }
    }
}
