package com.partho.diya

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject

/** সব ডেটা (API key, মেমোরি, পাসওয়ার্ড) এনক্রিপ্টেড অবস্থায় ফোনে থাকে */
object Store {
    private lateinit var sp: SharedPreferences

    fun init(c: Context) {
        val mk = MasterKey.Builder(c).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        sp = EncryptedSharedPreferences.create(
            c, "diya_secure", mk,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    private fun s(k: String, d: String = "") = sp.getString(k, d) ?: d
    private fun p(k: String, v: String) { sp.edit().putString(k, v).apply() }

    var geminiKeys: String
        get() = s("gk")
        set(v) = p("gk", v)
    var geminiModel: String
        get() = s("gm", "gemini-3.5-flash")
        set(v) = p("gm", v)
    var groqKeys: String
        get() = s("qk")
        set(v) = p("qk", v)
    var groqModel: String
        get() = s("qm", "openai/gpt-oss-20b")
        set(v) = p("qm", v)
    var haUrl: String
        get() = s("ha")
        set(v) = p("ha", v)
    var haToken: String
        get() = s("hat")
        set(v) = p("hat", v)
    var userName: String
        get() = s("name", "Badhan")
        set(v) = p("name", v)
    var voiceName: String
        get() = s("vn")
        set(v) = p("vn", v)
    var pin: String
        get() = s("pin")
        set(v) = p("pin", v)
    var cloneUrl: String
        get() = s("cu")
        set(v) = p("cu", v)
    var cloneSample: String
        get() = s("cs")
        set(v) = p("cs", v)
    var lang: String
        get() = s("lang", "bn-BD")
        set(v) = p("lang", v)
    var speakAll: String
        get() = s("sa", "1")
        set(v) = p("sa", v)
    var pitch: Float
        get() = sp.getFloat("pitch", 1.2f)
        set(v) { sp.edit().putFloat("pitch", v).apply() }
    var rate: Float
        get() = sp.getFloat("rate", 1.0f)
        set(v) { sp.edit().putFloat("rate", v).apply() }
    var gIdx: Int
        get() = sp.getInt("gi", 0)
        set(v) { sp.edit().putInt("gi", v).apply() }
    var qIdx: Int
        get() = sp.getInt("qi", 0)
        set(v) { sp.edit().putInt("qi", v).apply() }

    private fun list(k: String): List<String> {
        val a = JSONArray(s(k, "[]"))
        return List(a.length()) { a.getString(it) }
    }
    private fun saveList(k: String, l: List<String>) = p(k, JSONArray(l).toString())

    fun memories() = list("mem")
    fun addMemory(t: String) = saveList("mem", memories() + t)
    fun forget(k: String) = saveList("mem", memories().filterNot { it.contains(k, true) })

    fun triggers() = list("trg")
    fun addTrigger(t: String) = saveList("trg", triggers() + t)
    fun removeTrigger(t: String) = saveList("trg", triggers() - t)

    fun samples() = list("smp")
    fun addSample(t: String) = saveList("smp", samples() + t)
    fun removeSample(t: String) = saveList("smp", samples() - t)

    fun history(): List<Pair<String, String>> {
        val a = JSONArray(s("hist", "[]"))
        return List(a.length()) { val o = a.getJSONObject(it); o.getString("r") to o.getString("t") }
    }
    fun addHistory(role: String, text: String) {
        val l = history().takeLast(59)
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("r", it.first).put("t", it.second)) }
        a.put(JSONObject().put("r", role).put("t", text))
        p("hist", a.toString())
    }
}
