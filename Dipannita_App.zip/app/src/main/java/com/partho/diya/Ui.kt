package com.partho.diya

import android.Manifest
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import android.provider.Settings
import android.util.Base64
import android.webkit.MimeTypeMap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

val Red = Color(0xFFFF1744)
val Bg = Color(0xFF07040A)
val Panel = Color(0xFF111014)
val Line = Color(0xFF2A2A30)
val Green = Color(0xFF2EE046)

@Composable
fun DiyaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(primary = Red, background = Bg, surface = Panel, onSurface = Color.White, onBackground = Color.White),
        content = content
    )
}

// ---------- ফাইল পড়া ----------
fun readAtt(c: Context, u: Uri): Att {
    val mime = c.contentResolver.getType(u) ?: "application/octet-stream"
    var name = "file"
    c.contentResolver.query(u, null, null, null, null)?.use {
        if (it.moveToFirst()) { val i = it.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (i >= 0) name = it.getString(i) }
    }
    val bytes = c.contentResolver.openInputStream(u)?.use { it.readBytes() } ?: ByteArray(0)
    if (bytes.size > 18_000_000) return Att(name, mime, null, "(ফাইলটি অনেক বড় — ১৮MB এর কম দিন)")
    return when {
        mime.startsWith("image/") -> {
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            if (bmp == null) Att(name, mime, Base64.encodeToString(bytes, Base64.NO_WRAP), null)
            else {
                val s = 1600f / max(bmp.width, bmp.height)
                val b2 = if (s < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * s).toInt(), (bmp.height * s).toInt(), true) else bmp
                val o = ByteArrayOutputStream()
                b2.compress(Bitmap.CompressFormat.JPEG, 85, o)
                Att(name, "image/jpeg", Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP), null)
            }
        }
        mime.startsWith("video/") || mime.startsWith("audio/") || mime == "application/pdf" ->
            Att(name, mime, Base64.encodeToString(bytes, Base64.NO_WRAP), null)
        else -> Att(name, mime, null, String(bytes).take(60000))
    }
}

fun addSample(c: Context, u: Uri) {
    val mime = c.contentResolver.getType(u) ?: ""
    val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime) ?: "bin"
    val f = File(c.filesDir, "voice_${System.currentTimeMillis()}.$ext")
    c.contentResolver.openInputStream(u)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
    Store.addSample(f.path)
    if (Store.cloneSample.isBlank()) Store.cloneSample = f.path
}

// ---------- Root ----------
@Composable
fun Root() {
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
    LaunchedEffect(Unit) {
        AppState.loadHistory()
        perms.launch(arrayOf(
            Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.ANSWER_PHONE_CALLS,
            Manifest.permission.READ_CONTACTS, Manifest.permission.SEND_SMS, Manifest.permission.READ_PHONE_STATE
        ))
    }
    Box(Modifier.fillMaxSize().background(Bg)) {
        Particles()
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f)) {
                when (AppState.screen) {
                    Screen.HOME -> HomeScreen()
                    Screen.CHAT -> ChatScreen()
                    Screen.TRIGGERS -> TriggersScreen()
                    Screen.SETTINGS -> SettingsScreen()
                }
            }
            BottomBar()
        }
    }
}

@Composable
fun Particles() {
    val pts = remember { val r = Random(7); List(55) { Triple(r.nextFloat(), r.nextFloat(), 1f + r.nextFloat() * 2.5f) } }
    Canvas(Modifier.fillMaxSize()) {
        pts.forEach { (x, y, s) -> drawCircle(Red.copy(alpha = .5f), s.dp.toPx(), Offset(x * size.width, y * size.height)) }
    }
}

// ---------- নিচের বার ----------
@Composable
fun BottomBar() {
    Box(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp).height(84.dp)) {
        Row(
            Modifier.fillMaxWidth().height(64.dp).align(Alignment.BottomCenter)
                .clip(RoundedCornerShape(32.dp)).background(Panel).border(1.dp, Line, RoundedCornerShape(32.dp)),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Tab("🏠", "Home", Screen.HOME, Modifier.weight(1f))
            Tab("💬", "Chat", Screen.CHAT, Modifier.weight(1f))
            Spacer(Modifier.weight(1f))
            Tab("⚡", "Triggers", Screen.TRIGGERS, Modifier.weight(1f))
            Tab("⚙️", "Settings", Screen.SETTINGS, Modifier.weight(1f))
        }
        MicButton(Modifier.align(Alignment.TopCenter))
    }
}

@Composable
fun Tab(icon: String, label: String, s: Screen, m: Modifier) {
    val sel = AppState.screen == s
    Column(m.clickable { AppState.screen = s }, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(icon, fontSize = 20.sp, color = if (sel) Red else Color.Gray)
        Text(label, fontSize = 11.sp, color = if (sel) Red else Color.Gray)
    }
}

@Composable
fun MicButton(m: Modifier) {
    val active = AppState.listening || AppState.speaking
    val sc by animateFloatAsState(if (active) 1.12f + AppState.level * .2f else 1f, label = "mic")
    Box(
        m.size(64.dp).scale(sc).clip(CircleShape).background(Bg).border(2.dp, Red, CircleShape).clickable {
            when {
                AppState.listening -> DiyaVoice.stopListen()
                AppState.speaking -> DiyaVoice.stopSpeak()
                else -> DiyaVoice.listen { AppState.send(it, null, true) }
            }
        },
        contentAlignment = Alignment.Center
    ) { Text(if (AppState.listening) "👂" else if (AppState.speaking) "🔊" else "🎙", fontSize = 26.sp) }
}


// ---------- হোম ----------
@Composable
fun Header() {
    Row(Modifier.fillMaxWidth().padding(20.dp, 16.dp), verticalAlignment = Alignment.CenterVertically) {
        CircleBtn("☰") { AppState.screen = Screen.SETTINGS }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text("Hello, ${AppState.name}", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("How can I assist you today?", color = Color.Gray, fontSize = 14.sp)
        }
        CircleBtn("🔔") { }
    }
}

@Composable
fun CircleBtn(t: String, onClick: () -> Unit) {
    Box(Modifier.size(46.dp).clip(CircleShape).border(1.dp, Line, CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(t, fontSize = 18.sp)
    }
}

@Composable
fun HomeScreen() {
    val inf = rememberInfiniteTransition(label = "o")
    val rot by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "r")
    val pulse by inf.animateFloat(.94f, 1.06f, infiniteRepeatable(tween(1500), RepeatMode.Reverse), label = "p")
    Column(Modifier.fillMaxSize()) {
        Header()
        Column(Modifier.weight(1f).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Orb(rot, pulse)
            Sphere(rot)
            val line = when {
                AppState.listening -> AppState.partial.ifBlank { "শুনছি…" }
                AppState.busy -> AppState.status
                else -> AppState.lastReply.take(160)
            }
            Text(line, color = Color(0xFFBBBBBB), fontSize = 14.sp, textAlign = TextAlign.Center, maxLines = 3, modifier = Modifier.padding(horizontal = 28.dp, vertical = 4.dp))
        }
        ChatInput { AppState.screen = Screen.CHAT }
    }
}

@Composable
fun Orb(rot: Float, pulse: Float) {
    val lv = AppState.level
    val active = AppState.listening || AppState.speaking || AppState.busy
    Canvas(Modifier.size(230.dp)) {
        val c = center
        val u = 1.dp.toPx()
        drawCircle(Brush.radialGradient(listOf(Red.copy(.45f), Color.Transparent), c, 112 * u), 112 * u, c)
        val core = 52 * u * pulse * (1f + lv * .3f) * (if (active) 1.08f else 1f)
        drawCircle(Brush.radialGradient(listOf(Color.White, Red, Color(0xFF7A0020)), c, core), core, c)
        drawCircle(Color.White.copy(.5f), 80 * u, c, style = Stroke(1.2f * u))
        drawArc(Red, rot, 70f, false, Offset(c.x - 80 * u, c.y - 80 * u), Size(160 * u, 160 * u), style = Stroke(4 * u, cap = StrokeCap.Round))
        drawArc(Red, rot + 180f, 70f, false, Offset(c.x - 80 * u, c.y - 80 * u), Size(160 * u, 160 * u), style = Stroke(4 * u, cap = StrokeCap.Round))
        for (k in 0..2) {
            val a = Math.toRadians((rot * (1f + k * .4f) + k * 120f).toDouble())
            val rr = (92 + k * 6) * u
            drawCircle(Red, (3 + k) * u, Offset(c.x + cos(a).toFloat() * rr, c.y + sin(a).toFloat() * rr))
        }
    }
}

@Composable
fun Sphere(rot: Float) {
    val pts = remember {
        List(650) { i ->
            val y = 1f - 2f * (i + .5f) / 650f
            val r = sqrt(1f - y * y)
            val th = i * 2.39996f
            floatArrayOf(cos(th) * r, y, sin(th) * r)
        }
    }
    val lv = AppState.level
    Box(Modifier.fillMaxWidth().height(210.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxWidth().height(6.dp)) {
            var x = 0f
            while (x < size.width) { drawCircle(Red, 2.dp.toPx(), Offset(x, size.height / 2)); x += 12.dp.toPx() }
        }
        Canvas(Modifier.size(210.dp)) {
            val rad = 96.dp.toPx() * (1f + lv * .12f)
            val a = Math.toRadians(rot.toDouble()).toFloat()
            val ca = cos(a); val sa = sin(a)
            for (p in pts) {
                val x = p[0] * ca + p[2] * sa
                val z = -p[0] * sa + p[2] * ca
                val d = (z + 1f) / 2f
                drawCircle(Green.copy(alpha = .35f + .65f * d), (1f + 1.2f * d).dp.toPx(), Offset(center.x + x * rad, center.y + p[1] * rad))
            }
        }
    }
}

// ---------- চ্যাট ইনপুট ----------
@Composable
fun ChatInput(onSent: () -> Unit = {}) {
    val ctx = LocalContext.current
    var text by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) AppState.pendingAtt = readAtt(ctx, u)
    }
    Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
        AppState.pendingAtt?.let {
            Row(Modifier.padding(bottom = 6.dp).clip(RoundedCornerShape(12.dp)).background(Panel).padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("📎 ${it.name.take(30)}", color = Color.White, fontSize = 13.sp)
                Text("  ✕", color = Red, modifier = Modifier.clickable { AppState.pendingAtt = null })
            }
        }
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(30.dp)).border(1.dp, Line, RoundedCornerShape(30.dp)).background(Panel).padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box {
                TextButton(onClick = { menu = true }) { Text("+", fontSize = 28.sp, color = Color.Gray) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("🖼 ছবি") }, onClick = { menu = false; picker.launch("image/*") })
                    DropdownMenuItem(text = { Text("🎬 ভিডিও") }, onClick = { menu = false; picker.launch("video/*") })
                    DropdownMenuItem(text = { Text("📄 ফাইল") }, onClick = { menu = false; picker.launch("*/*") })
                }
            }
            BasicTextField(
                value = text, onValueChange = { text = it }, maxLines = 4,
                modifier = Modifier.weight(1f).padding(vertical = 14.dp),
                textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                cursorBrush = SolidColor(Red),
                decorationBox = { inner -> Box { if (text.isEmpty()) Text("Ask Dipannita anything...", color = Color.Gray); inner() } }
            )
            TextButton(onClick = {
                val t = text.trim()
                if (t.isNotEmpty() || AppState.pendingAtt != null) {
                    val a = AppState.pendingAtt
                    AppState.pendingAtt = null
                    text = ""
                    AppState.send(t, a, false)
                    onSent()
                }
            }) { Text("➤", color = Red, fontSize = 24.sp) }
        }
    }
}

// ---------- চ্যাট ----------
@Composable
fun ChatScreen() {
    val st = rememberLazyListState()
    LaunchedEffect(AppState.msgs.size, AppState.busy) {
        if (st.layoutInfo.totalItemsCount > 0) st.animateScrollToItem(st.layoutInfo.totalItemsCount - 1)
    }
    Column(Modifier.fillMaxSize()) {
        Text("Chat", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.padding(20.dp, 16.dp))
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = st, contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(AppState.msgs) { Bubble(it) }
            if (AppState.busy) item { Text("⏳ ${AppState.status}", color = Color.Gray) }
        }
        ChatInput()
    }
}

@Composable
fun Bubble(m: ChatMsg) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.mine) Arrangement.End else Arrangement.Start) {
        Column(
            Modifier.widthIn(max = 300.dp).clip(RoundedCornerShape(18.dp))
                .background(if (m.mine) Red.copy(alpha = .85f) else Panel)
                .border(1.dp, if (m.mine) Red else Line, RoundedCornerShape(18.dp)).padding(12.dp)
        ) {
            if (m.image != null) {
                val bmp = remember(m.image) { BitmapFactory.decodeFile(m.image) }
                if (bmp != null) Image(bmp.asImageBitmap(), null, Modifier.fillMaxWidth().padding(bottom = 8.dp).clip(RoundedCornerShape(12.dp)))
            }
            Text(m.text, color = Color.White, fontSize = 15.sp)
        }
    }
}

// ---------- Triggers ----------
@Composable
fun TriggersScreen() {
    var list by remember { mutableStateOf(Store.triggers()) }
    var nw by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Triggers", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("প্রায়ই ব্যবহৃত কমান্ড সেভ করো, এক ট্যাপে চালাও", color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(bottom = 12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(nw, { nw = it }, Modifier.weight(1f), label = { Text("নতুন কমান্ড") }, colors = tfColors())
            Spacer(Modifier.width(8.dp))
            Button({ if (nw.isNotBlank()) { Store.addTrigger(nw.trim()); list = Store.triggers(); nw = "" } }, colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text("+") }
        }
        LazyColumn(Modifier.padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list) { t ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel).border(1.dp, Line, RoundedCornerShape(16.dp)).padding(start = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(t, Modifier.weight(1f), color = Color.White)
                    TextButton({ AppState.screen = Screen.CHAT; AppState.send(t, null, false) }) { Text("▶", color = Red) }
                    TextButton({ Store.removeTrigger(t); list = Store.triggers() }) { Text("✕", color = Color.Gray) }
                }
            }
        }
    }
}

// ---------- Settings ----------
@Composable
fun tfColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Red, unfocusedBorderColor = Line, focusedLabelColor = Red, cursorColor = Red,
    focusedTextColor = Color.White, unfocusedTextColor = Color.White
)

val Dots = object : VisualTransformation {
    override fun filter(text: AnnotatedString) =
        TransformedText(AnnotatedString(text.text.map { if (it == '\n') '\n' else '•' }.joinToString("")), OffsetMapping.Identity)
}

@Composable
fun Sect(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).border(1.dp, Line, RoundedCornerShape(24.dp)).background(Panel.copy(alpha = .8f)).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(title, color = Red, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        content()
    }
}

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var gk by remember { mutableStateOf(Store.geminiKeys) }
    var gm by remember { mutableStateOf(Store.geminiModel) }
    var qk by remember { mutableStateOf(Store.groqKeys) }
    var qm by remember { mutableStateOf(Store.groqModel) }
    var show by remember { mutableStateOf(false) }
    var gMsg by remember { mutableStateOf("") }
    var qMsg by remember { mutableStateOf("") }
    var ha by remember { mutableStateOf(Store.haUrl) }
    var hat by remember { mutableStateOf(Store.haToken) }
    var nm by remember { mutableStateOf(Store.userName) }
    var pin by remember { mutableStateOf(Store.pin) }
    var pitch by remember { mutableStateOf(Store.pitch) }
    var rate by remember { mutableStateOf(Store.rate) }
    var speakAll by remember { mutableStateOf(Store.speakAll == "1") }
    var vn by remember { mutableStateOf(Store.voiceName) }
    var vmenu by remember { mutableStateOf(false) }
    var gtts by remember { mutableStateOf(Store.geminiTts == "1") }
    var ttsm by remember { mutableStateOf(Store.ttsModel) }
    var ttsv by remember { mutableStateOf(Store.ttsVoice) }
    var tmenu by remember { mutableStateOf(false) }
    var clone by remember { mutableStateOf(Store.cloneUrl) }
    var samples by remember { mutableStateOf(Store.samples()) }
    var sel by remember { mutableStateOf(Store.cloneSample) }
    val pickA = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u -> if (u != null) { addSample(ctx, u); samples = Store.samples(); sel = Store.cloneSample } }
    val pickV = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u -> if (u != null) { addSample(ctx, u); samples = Store.samples(); sel = Store.cloneSample } }
    val btn = ButtonDefaults.buttonColors(containerColor = Red)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Settings", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White)

        Sect("GEMINI API") {
            OutlinedTextField(gk, { gk = it }, Modifier.fillMaxWidth(), label = { Text("API keys (one per line)") }, minLines = 5,
                visualTransformation = if (show) VisualTransformation.None else Dots, colors = tfColors())
            Row(verticalAlignment = Alignment.CenterVertically) { Switch(show, { show = it }); Text("  Show keys", color = Color.Gray) }
            OutlinedTextField(gm, { gm = it }, Modifier.fillMaxWidth(), label = { Text("Model") }, singleLine = true, colors = tfColors())
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button({ Store.geminiKeys = gk.trim(); Store.geminiModel = gm.trim(); Store.gIdx = 0; gMsg = "✅ সেভ হয়েছে" }, colors = btn) { Text("Save") }
                OutlinedButton({
                    Store.geminiKeys = gk.trim(); Store.geminiModel = gm.trim(); Store.gIdx = 0
                    scope.launch { gMsg = "⏳ টেস্ট হচ্ছে…"; gMsg = Llm.test("gemini") }
                }, border = BorderStroke(1.dp, Red)) { Text("Save & Test", color = Red) }
            }
            if (gMsg.isNotBlank()) Text(gMsg, color = Color.LightGray, fontSize = 13.sp)
        }

        Sect("GROQ API (backup, high limit)") {
            OutlinedTextField(qk, { qk = it }, Modifier.fillMaxWidth(), label = { Text("Groq API keys (one per line)") }, minLines = 3,
                visualTransformation = if (show) VisualTransformation.None else Dots, colors = tfColors())
            OutlinedTextField(qm, { qm = it }, Modifier.fillMaxWidth(), label = { Text("Groq model") }, singleLine = true, colors = tfColors())
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button({ Store.groqKeys = qk.trim(); Store.groqModel = qm.trim(); Store.qIdx = 0; qMsg = "✅ সেভ হয়েছে" }, colors = btn) { Text("Save") }
                OutlinedButton({
                    Store.groqKeys = qk.trim(); Store.groqModel = qm.trim(); Store.qIdx = 0
                    scope.launch { qMsg = "⏳ টেস্ট হচ্ছে…"; qMsg = Llm.test("groq") }
                }, border = BorderStroke(1.dp, Red)) { Text("Save & Test", color = Red) }
            }
            Text(qMsg.ifBlank { "Gemini'র limit শেষ হলে বা Gemini key না থাকলে স্বয়ংক্রিয়ভাবে ব্যবহার হবে।" }, color = Color.Gray, fontSize = 13.sp)
        }

        Sect("প্রোফাইল ও সিকিউরিটি") {
            OutlinedTextField(nm, { nm = it }, Modifier.fillMaxWidth(), label = { Text("তোমার নাম") }, singleLine = true, colors = tfColors())
            OutlinedTextField(pin, { pin = it }, Modifier.fillMaxWidth(), label = { Text("ফোন আনলক PIN/পাসওয়ার্ড (\"ফোন আনলক করো\" কমান্ডের জন্য)") },
                singleLine = true, visualTransformation = if (show) VisualTransformation.None else Dots, colors = tfColors())
            Button({ Store.userName = nm.trim(); AppState.name = nm.trim(); Store.pin = pin }, colors = btn) { Text("Save") }
        }

        Sect("SMART HOME (Home Assistant)") {
            OutlinedTextField(ha, { ha = it }, Modifier.fillMaxWidth(), label = { Text("Address, e.g. http://192.168.0.10:8123") }, singleLine = true, colors = tfColors())
            OutlinedTextField(hat, { hat = it }, Modifier.fillMaxWidth(), label = { Text("Long-lived access token") }, singleLine = true,
                visualTransformation = if (show) VisualTransformation.None else Dots, colors = tfColors())
            Button({ Store.haUrl = ha.trim(); Store.haToken = hat.trim() }, colors = btn) { Text("Save") }
        }

        Sect("ভয়েস") {
            Row(verticalAlignment = Alignment.CenterVertically) { Switch(gtts, { gtts = it; Store.geminiTts = if (it) "1" else "0" }); Text("  মেয়েদের Gemini ভয়েস (প্রস্তাবিত)", color = Color.Gray) }
            Box {
                OutlinedButton({ tmenu = true }, border = BorderStroke(1.dp, Red)) { Text("Gemini ভয়েস: $ttsv", color = Red) }
                DropdownMenu(tmenu, { tmenu = false }) {
                    listOf("Kore", "Aoede", "Leda", "Zephyr", "Sulafat", "Despina", "Callirrhoe", "Autonoe").forEach { n ->
                        DropdownMenuItem(text = { Text(n) }, onClick = { ttsv = n; Store.ttsVoice = n; tmenu = false })
                    }
                }
            }
            OutlinedTextField(ttsm, { ttsm = it }, Modifier.fillMaxWidth(), label = { Text("TTS model") }, singleLine = true, colors = tfColors())
            Button({ Store.ttsModel = ttsm.trim() }, colors = btn) { Text("Save TTS model") }
            Row(verticalAlignment = Alignment.CenterVertically) { Switch(speakAll, { speakAll = it; Store.speakAll = if (it) "1" else "0" }); Text("  সব উত্তর পড়ে শোনাও", color = Color.Gray) }
            Text("Pitch: ${"%.2f".format(pitch)}", color = Color.Gray, fontSize = 13.sp)
            Slider(pitch, { pitch = it }, valueRange = 0.5f..2f, onValueChangeFinished = { Store.pitch = pitch })
            Text("গতি: ${"%.2f".format(rate)}", color = Color.Gray, fontSize = 13.sp)
            Slider(rate, { rate = it }, valueRange = 0.5f..2f, onValueChangeFinished = { Store.rate = rate })
            Box {
                OutlinedButton({ vmenu = true }, border = BorderStroke(1.dp, Red)) { Text("ভয়েস: ${vn.ifBlank { "ডিফল্ট" }.take(28)}", color = Red) }
                DropdownMenu(vmenu, { vmenu = false }) {
                    DropdownMenuItem(text = { Text("ডিফল্ট") }, onClick = { vn = ""; Store.voiceName = ""; vmenu = false })
                    DiyaVoice.voices().forEach { v ->
                        DropdownMenuItem(text = { Text("${v.name} (${v.locale})", fontSize = 12.sp) }, onClick = { vn = v.name; Store.voiceName = v.name; vmenu = false })
                    }
                }
            }
            Button({ DiyaVoice.speak("হ্যালো, আমি দিপান্নিতা। কেমন আছো?") }, colors = btn) { Text("ভয়েস টেস্ট") }
        }

        Sect("কাস্টম ভয়েস স্যাম্পল (Voice Clone)") {
            Text("⚠️ শুধু নিজের বা যার স্পষ্ট অনুমতি আছে তার ভয়েস ব্যবহার করো। ক্লোন করতে নিজের একটি voice-clone সার্ভার (যেমন XTTS) লাগবে — Gemini/Groq ক্লোন করতে পারে না। সার্ভার না দিলে ডিভাইসের ভয়েসই ব্যবহার হবে।",
                color = Color.Gray, fontSize = 12.sp)
            OutlinedTextField(clone, { clone = it }, Modifier.fillMaxWidth(), label = { Text("Voice-clone server URL (ঐচ্ছিক)") }, singleLine = true, colors = tfColors())
            Button({ Store.cloneUrl = clone.trim() }, colors = btn) { Text("Save URL") }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton({ pickA.launch("audio/*") }, border = BorderStroke(1.dp, Red)) { Text("🎵 অডিও", color = Red) }
                OutlinedButton({ pickV.launch("video/*") }, border = BorderStroke(1.dp, Red)) { Text("🎬 ভিডিও", color = Red) }
            }
            samples.forEach { p ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { Store.cloneSample = p; sel = p }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(if (p == sel) "✅" else "⚪", modifier = Modifier.padding(end = 8.dp))
                    Text(File(p).name, Modifier.weight(1f), color = Color.White, fontSize = 13.sp)
                    Text("✕", color = Color.Gray, modifier = Modifier.clickable {
                        Store.removeSample(p); File(p).delete()
                        if (Store.cloneSample == p) Store.cloneSample = ""
                        samples = Store.samples(); sel = Store.cloneSample
                    })
                }
            }
        }

        Sect("পারমিশন") {
            Text(if (DiyaAccess.inst != null) "✅ Accessibility চালু আছে" else "❌ Accessibility বন্ধ — ফোন কন্ট্রোলের জন্য অবশ্যই চালু করো", color = Color.LightGray, fontSize = 13.sp)
            Button({ ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, colors = btn) { Text("Accessibility সেটিংস") }
            OutlinedButton({
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
            }, border = BorderStroke(1.dp, Red)) { Text("Display over other apps", color = Red) }
        }
        Spacer(Modifier.height(24.dp))
    }
}
