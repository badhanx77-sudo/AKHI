package com.partho.diya

data class Msg(val role: String, val text: String, val images: List<Pair<String, String>> = emptyList())
data class Att(val name: String, val mime: String, val b64: String?, val text: String?)
data class ChatMsg(val mine: Boolean, val text: String, val image: String? = null, val att: String? = null)
enum class Screen { HOME, CHAT, TRIGGERS, SETTINGS }
