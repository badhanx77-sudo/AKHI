package com.partho.diya

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.annotation.RequiresApi
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.ByteArrayOutputStream
import kotlin.coroutines.resume

class DiyaAccess : AccessibilityService() {
    companion object { @Volatile var inst: DiyaAccess? = null }

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(intent: Intent?): Boolean { inst = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun screenSize(): Pair<Float, Float> {
        val d = resources.displayMetrics
        return d.widthPixels.toFloat() to d.heightPixels.toFloat()
    }

    fun dump(): String {
        val r = rootInActiveWindow ?: return "(স্ক্রিন পড়া যাচ্ছে না)"
        val sb = StringBuilder("app=${r.packageName}\n")
        var n = 0
        fun walk(x: AccessibilityNodeInfo?) {
            if (x == null || n > 160) return
            val t = x.text?.toString() ?: ""
            val d = x.contentDescription?.toString() ?: ""
            if (t.isNotBlank() || d.isNotBlank() || x.isEditable) {
                n++
                val b = Rect(); x.getBoundsInScreen(b)
                sb.append("- ").append(t.ifBlank { d })
                if (x.isClickable) sb.append(" [click]")
                if (x.isEditable) sb.append(" [input]")
                sb.append(" @${b.centerX()},${b.centerY()}\n")
            }
            for (i in 0 until x.childCount) walk(x.getChild(i))
        }
        walk(r)
        return sb.toString()
    }

    fun clickText(t: String): Boolean {
        val r = rootInActiveWindow ?: return false
        val nodes = r.findAccessibilityNodeInfosByText(t)
            .sortedByDescending { it.text?.toString() == t || it.contentDescription?.toString() == t }
        for (nd in nodes) {
            var c: AccessibilityNodeInfo? = nd
            while (c != null && !c.isClickable) c = c.parent
            if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        nodes.firstOrNull()?.let {
            val b = Rect(); it.getBoundsInScreen(b)
            tap(b.centerX().toFloat(), b.centerY().toFloat())
            return true
        }
        return false
    }

    private fun findEditable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isEditable) return n
        for (i in 0 until n.childCount) findEditable(n.getChild(i))?.let { return it }
        return null
    }

    fun typeText(t: String): Boolean {
        val r = rootInActiveWindow ?: return false
        var f = r.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (f == null || !f.isEditable) f = findEditable(r)
        val node = f ?: return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long = 300): Boolean {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, ms)).build()
        return dispatchGesture(g, null, null)
    }

    fun tap(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build()
        return dispatchGesture(g, null, null)
    }

    fun global(key: String): Boolean = performGlobalAction(
        when (key) {
            "back" -> GLOBAL_ACTION_BACK
            "home" -> GLOBAL_ACTION_HOME
            "recents" -> GLOBAL_ACTION_RECENTS
            "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
            else -> GLOBAL_ACTION_HOME
        }
    )

    @RequiresApi(Build.VERSION_CODES.R)
    suspend fun shot(): String? = suspendCancellableCoroutine<String?> { cont ->
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                try {
                    val hb = r.hardwareBuffer
                    val bmp = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)!!.copy(Bitmap.Config.ARGB_8888, false)
                    hb.close()
                    val sc = Bitmap.createScaledBitmap(bmp, 720, (720f * bmp.height / bmp.width).toInt(), true)
                    val o = ByteArrayOutputStream()
                    sc.compress(Bitmap.CompressFormat.JPEG, 70, o)
                    cont.resume(Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP))
                } catch (e: Exception) { cont.resume(null) }
            }
            override fun onFailure(code: Int) { cont.resume(null) }
        })
    }
}
