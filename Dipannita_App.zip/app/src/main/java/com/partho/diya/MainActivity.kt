package com.partho.diya

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        Actions.app = applicationContext
        DiyaVoice.init(this)
        setContent { DiyaTheme { Root() } }
    }
}
