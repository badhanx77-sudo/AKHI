package com.partho.diya

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaPlayer
import android.util.Base64
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File
import java.util.Locale
import java.util.concurrent.TimeUnit

object DiyaVoice {
    private lateinit var app: Context
    private var tts: TextToSpeech? = null
    private var ready = false
    private var sr: SpeechRecognizer? = null
    private var mp: MediaPlayer? = null
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(Dispatchers.IO)
    private val http = OkHttpClient.Builder().readTimeout(120, TimeUnit.SECONDS).build()
    private var onDone: () -> Unit = {}
    private var track: AudioTrack? = null

    fun init(c: Context) {
        app = c.applicationContext
        tts = TextToSpeech(app) { st ->
            if (st == TextToSpeech.SUCCESS) {
                ready = true
                val l = Locale.forLanguageTag(Store.lang)
                if (tts?.isLanguageAvailable(l) ?: TextToSpeech.LANG_NOT_SUPPORTED >= 0) tts?.language = l
            }
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { main.post { finish() } }
            @Deprecated("deprecated") override fun onError(id: String?) { main.post { finish() } }
        })
    }

    fun voices(): List<Voice> = tts?.voices?.sortedBy { it.locale.toString() } ?: emptyList()

    private fun finish() {
        AppState.speaking = false
        val d = onDone; onDone = {}
        d()
    }

    fun speak(text: String, done: () -> Unit = {}) {
        if (text.isBlank()) { done(); return }
        onDone = done
        AppState.speaking = true
        if (Store.cloneUrl.isNotBlank() && Store.cloneSample.isNotBlank()) {
            scope.launch { if (!remote(text)) main.post { local(text) } }
        } else if (Store.geminiTts == "1" && Llm.keys(Store.geminiKeys).isNotEmpty()) {
            scope.launch { if (!geminiTts(text)) main.post { local(text) } }
        } else local(text)
    }

    private fun local(t: String) {
        val e = tts
        if (e == null || !ready) { finish(); return }
        e.setPitch(Store.pitch)
        e.setSpeechRate(Store.rate)
        val vn = Store.voiceName
        if (vn.isNotBlank()) e.voices?.firstOrNull { it.name == vn }?.let { e.voice = it }
        e.speak(t.take(3500), TextToSpeech.QUEUE_FLUSH, null, "diya")
    }

    /** আপনার নিজের voice-clone সার্ভার থাকলে (যেমন XTTS) সেখানে text + sample পাঠায়, WAV ফেরত আসে */
    private fun remote(text: String): Boolean {
        return try {
            val f = File(Store.cloneSample)
            if (!f.exists()) return false
            val body = MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart("text", text)
                .addFormDataPart("language", Store.lang.take(2))
                .addFormDataPart("speaker", f.name, f.asRequestBody("application/octet-stream".toMediaType()))
                .build()
            http.newCall(Request.Builder().url(Store.cloneUrl).post(body).build()).execute().use { r ->
                if (!r.isSuccessful) return false
                val out = File(app.cacheDir, "tts_remote.wav")
                out.writeBytes(r.body!!.bytes())
                main.post { play(out) }
            }
            true
        } catch (e: Exception) { false }
    }

    /** Gemini TTS: মেয়েদের কণ্ঠের prebuilt ভয়েস (Kore, Aoede, Leda...) — PCM 24kHz mono */
    private fun geminiTts(text: String): Boolean {
        val keys = Llm.keys(Store.geminiKeys)
        for (k in keys) {
            try {
                val body = JSONObject()
                    .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", text.take(1200))))))
                    .put("generationConfig", JSONObject()
                        .put("responseModalities", JSONArray().put("AUDIO"))
                        .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig",
                            JSONObject().put("voiceName", Store.ttsVoice)))))
                val req = Request.Builder()
                    .url("https://generativelanguage.googleapis.com/v1beta/models/${Store.ttsModel}:generateContent")
                    .header("x-goog-api-key", k)
                    .post(body.toString().toRequestBody("application/json".toMediaType())).build()
                val res = http.newCall(req).execute().use { r ->
                    if (!r.isSuccessful) null else r.body?.string()
                } ?: continue
                val parts = JSONObject(res).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
                var b64: String? = null
                for (i in 0 until parts.length()) {
                    val inl = parts.getJSONObject(i).optJSONObject("inlineData")
                    if (inl != null) { b64 = inl.getString("data"); break }
                }
                val pcm = Base64.decode(b64 ?: continue, Base64.DEFAULT)
                main.post { playPcm(pcm) }
                return true
            } catch (e: Exception) { /* পরের key */ }
        }
        return false
    }

    private fun playPcm(pcm: ByteArray) {
        try {
            track?.release()
            val frames = pcm.size / 2
            val t = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(pcm.size)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            t.write(pcm, 0, pcm.size)
            t.setNotificationMarkerPosition(frames - 1)
            t.setPlaybackPositionUpdateListener(object : AudioTrack.OnPlaybackPositionUpdateListener {
                override fun onMarkerReached(a: AudioTrack?) { main.post { finish() } }
                override fun onPeriodicNotification(a: AudioTrack?) {}
            })
            track = t
            t.play()
        } catch (e: Exception) { finish() }
    }

    private fun play(f: File) {
        try {
            mp?.release()
            mp = MediaPlayer().apply {
                setDataSource(f.path)
                setOnCompletionListener { finish() }
                prepare(); start()
            }
        } catch (e: Exception) { finish() }
    }

    fun stopSpeak() {
        tts?.stop(); mp?.release(); mp = null
        try { track?.stop(); track?.release() } catch (e: Exception) { }
        track = null
        finish()
    }

    fun stopListen() {
        sr?.stopListening()
        AppState.listening = false
    }

    fun listen(onResult: (String) -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(app)) { AppState.status = "Speech recognition নেই"; return }
        stopSpeak()
        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(app)
        sr?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rms: Float) { AppState.level = ((rms + 2f) / 12f).coerceIn(0f, 1f) }
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(e: Int) {
                AppState.listening = false; AppState.level = 0f; AppState.partial = ""
                if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) AppState.status = "মাইক্রোফোন পারমিশন দাও"
            }
            override fun onResults(b: Bundle?) {
                AppState.listening = false; AppState.level = 0f; AppState.partial = ""
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) onResult(t)
            }
            override fun onPartialResults(b: Bundle?) {
                AppState.partial = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
            }
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Store.lang)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        sr?.startListening(i)
        AppState.listening = true
    }
}
